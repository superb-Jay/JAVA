package com.smartstore.run;

import com.smartstore.view.MainMenu;

public class Run {
    public static void main(String[] args) {
        new MainMenu().mainMenu();

        System.out.println("Program Finished.");
    }
}
